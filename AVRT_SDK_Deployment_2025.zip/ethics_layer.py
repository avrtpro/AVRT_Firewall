# ethics_layer.py

def check_ethics(text):
    unsafe_keywords = ["kill", "suicide", "harm"]
    for word in unsafe_keywords:
        if word in text.lower():
            return False
    return True
