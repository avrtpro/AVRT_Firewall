# middleware.py

def _mock_llm_call(prompt):
    return "This is a simulated response from the LLM."

def avrt_middleware(user_input):
    print("[AVRT] Intercepting input...")
    # Simulate SPIEL + THT check
    if "harm" in user_input.lower():
        return "[AVRT BLOCKED] Potentially unsafe content detected."
    response = _mock_llm_call(user_input)
    return f"[AVRT OUTPUT] {response}"
