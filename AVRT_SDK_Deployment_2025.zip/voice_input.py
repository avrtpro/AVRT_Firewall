# voice_input.py

def record_audio():
    print("[VOICE INPUT] Simulated recording...")  # Placeholder for Whisper or other STT API
    return "Simulated transcribed text"
